# Zombie Smash – OpenSSL 1.0.2u ARM/armeabi build

This repository builds OpenSSL 1.0.2u shared libraries for the legacy Android
`armeabi` (32-bit ARM / ARMv5TE) ABI using Android NDK r16b.

## What this does
- Builds `libcrypto.so` and `libssl.so` from the OpenSSL 1.0.2u source archive.
- Checks the ELF architecture and confirms `SSLv3_server_method` is exported.
- Uploads the resulting libraries as a GitHub Actions artifact.

## What this does NOT do
It does not modify or re-sign the Zombie Smash APK. The libraries must first be
checked against the APK's exact dependencies and loader behavior. A successful
build is not proof that the game will run.

## Upload/run from a phone
1. Create a **public** GitHub repository (public repositories get standard
   GitHub-hosted Actions usage without consuming the private-repository minutes
   quota; GitHub may still apply fair-use limits).
2. Upload all files and folders in this project, preserving `.github/workflows`.
3. Open the repository's **Actions** tab.
4. Select **Build OpenSSL 1.0.2u for armeabi** and tap **Run workflow**.
5. When complete, open the run and download the artifact named
   `openssl-1.0.2u-armeabi-libs`.

## Important
OpenSSL 1.0.2u is obsolete and has known security vulnerabilities. These
libraries are intended only for offline compatibility testing of this old game.
Do not use them for a network-facing or security-sensitive application.
