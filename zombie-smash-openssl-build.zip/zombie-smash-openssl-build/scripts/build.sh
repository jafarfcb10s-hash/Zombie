#!/usr/bin/env bash
# Optional local equivalent of the GitHub Actions build; expects NDK r16b installed.
set -euo pipefail
echo "Use the GitHub Actions workflow for the reproducible hosted build."
echo "See README.md."
